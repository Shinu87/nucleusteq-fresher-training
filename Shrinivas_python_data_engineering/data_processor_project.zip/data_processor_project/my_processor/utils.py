import re

class InvalidMemberDataError(Exception):
    """Custom exception raised for malformed member data."""
    pass

def validate_email(email: str) -> bool:
    """Validates email format using regex."""
    pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
    return bool(re.match(pattern, email))

def validate_phone(phone: str) -> bool:
    """Validates standard 10-digit phone numbers."""
    pattern = r"^(\+91[\-\s]?)?[0-9]{3,5}[\-\s]?[0-9]{4,7}$"
    return bool(re.match(pattern, phone))

def clean_and_validate_member(raw_data: dict) -> dict:
    """Cleans fields and validates data, raising custom exceptions on failure."""
    name = raw_data.get("name", "").strip()
    email = raw_data.get("email", "").strip()
    phone = raw_data.get("phone", "").strip()

    if not name:
        raise InvalidMemberDataError(f"Missing or empty name for member data: {raw_data}")
    
    if not validate_email(email):
        raise InvalidMemberDataError(f"Invalid email '{email}' for member '{name}'.")
        
    if not validate_phone(phone):
        raise InvalidMemberDataError(f"Invalid phone '{phone}' for member '{name}'.")

    return {"name": name, "email": email, "phone": phone}