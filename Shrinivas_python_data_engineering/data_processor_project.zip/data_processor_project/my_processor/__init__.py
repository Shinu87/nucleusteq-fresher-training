from my_processor.core import Member, MemberManager
from my_processor.utils import InvalidMemberDataError