from my_processor.utils import clean_and_validate_member, InvalidMemberDataError

class Member:
    """Object-Oriented representation of an individual user."""
    def __init__(self, name: str, email: str, phone: str):
        self.name = name
        self.email = email
        self.phone = phone

    def __str__(self):
        return f"Member(Name: {self.name}, Email: {self.email}, Phone: {self.phone})"

class MemberManager:
    """It manages a collection of Member profiles using lists and dictionaries."""
    def __init__(self):
        self.profiles = [] 

    def process_raw_data(self, raw_members: list):
        success_count = 0
        for raw in raw_members:
            name_label = raw.get("name", "Unknown")
            try:
                print(f"Processing member: {name_label}...", end=" ")
                cleaned = clean_and_validate_member(raw)
                
                member_obj = Member(cleaned["name"], cleaned["email"], cleaned["phone"])
                self.profiles.append(member_obj)
                
                print("Validation Successful.")
                success_count += 1
            except InvalidMemberDataError as e:
                print(f"Skipping.")
                print(f"Error: {e}")
            except Exception as e:
                print(f"Skipping.")
                print(f"System Error: {e}")
                
        print(f"Summary: {success_count} members processed successfully.")

    def filter_members_by_domain(self, domain: str) -> list:
        """Demonstrates Functional Programming using filter(), map(), and lambda."""

        # Using lambda and filter to find members whose emails end with a specific domain
        filtered_objs = filter(lambda m: m.email.endswith(domain), self.profiles)

        return list(map(lambda m: m.name, filtered_objs))