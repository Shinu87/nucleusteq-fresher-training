from my_processor.core import MemberManager

raw_members = [
    {"name": "Aarav Sharma", "email": "aarav.sharma@example.com", "phone": "9876543210"},
    {"name": "Priya Patel", "email": "priya.patel@example.com", "phone": "9123456789"},
    {"name": "Rahul Verma", "email": "rahul.verma@example.com", "phone": "9988776655"},
    {"name": "Ananya Iyer", "email": "ananya.iyer@example.com", "phone": "9765432109"},
    {"name": "InvalidData", "email": "bad-email", "phone": "555-0999"}
]

if __name__ == "__main__":
    print("--- Starting Member Processing ---")
    manager = MemberManager()
    manager.process_raw_data(raw_members)

    print("\n--- Testing Functional Programming Filter ---")
    filtered = manager.filter_members_by_domain("example.com")
    print("Filtered Members (example.com domain):", filtered)